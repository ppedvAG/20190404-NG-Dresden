import { TodosComponent } from './todos/todos.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StartviewComponent } from './startview/startview.component';
import { TodoDetailsComponent } from './todo-details/todo-details.component';

const routes: Routes = [
  { path: '', redirectTo: '/startview', pathMatch: 'full'},
  { path: 'startview', component: StartviewComponent},
  { path: 'todos', component: TodosComponent},
  { path: 'details/:id', component: TodoDetailsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
