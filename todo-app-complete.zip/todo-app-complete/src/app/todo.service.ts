import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { MessageService } from "./message.service";
import { Observable, of, pipe } from "rxjs";
import { catchError, map, tap } from "rxjs/operators";
import { Todo } from "./todo";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" })
};

@Injectable({
  providedIn: "root"
})
export class TodoService {
  private todosUrl = "api/todos";

  constructor(
    private http: HttpClient,
    private messageService: MessageService
  ) {}

  getTodos(): Observable<Todo[]> {
    return this.http.get<Todo[]>(this.todosUrl).pipe(
      tap(_ => this.log("fetched todos")),
      catchError(this.handleError("getTodos", []))
    );
  }
  getTodo(id: number): Observable<Todo> {
    const url = `${this.todosUrl}/${id}`;
    return this.http.get<Todo>(url).pipe(
      tap(_ => this.log(`fetched todo id=${id}`)),
      catchError(this.handleError<Todo>(`getTodo id=${id}`))
    );
  }

  updateTodo(todo: Todo): Observable<any> {
    return this.http.put(this.todosUrl, todo, httpOptions).pipe(
      tap(_ => this.log(`updated todo id=${todo.id}`)),
      catchError(this.handleError<any>(`updateTodo`))
    );
  }

  addTodo(todo: Todo): Observable<Todo> {
    return this.http.post<Todo>(this.todosUrl, todo, httpOptions).pipe(
      tap((newTodo: Todo) => this.log(`added todo w/ id=${newTodo.id}`)),
      catchError(this.handleError<Todo>(`addTodo`))
    );
  }

  deleteTodo(todo: Todo | number): Observable<Todo> {
    const id = typeof todo === "number" ? todo : todo.id;
    const url = `${this.todosUrl}/${id}`;
    return this.http.delete<Todo>(url, httpOptions).pipe(
      tap(_ => this.log(`deleted todo w/ id=${id}`)),
      catchError(this.handleError<Todo>(`deleteTodo`))
    );
  }

  searchTodo(filter: string): Observable<Todo[]> {
    if (!filter.trim()) {
      return of([]);
    }
    return this.http.get<Todo[]>(`${this.todosUrl}/?title=${filter}`).pipe(
      tap(_ => this.log(`found todos matching ${filter}`)),
      catchError(this.handleError<Todo[]>(`searchTodos`, []))
    );
  }
  /* Emit variable amount of values in a sequence and then emits a complete notification. */
  /* Converts the arguments to an observable sequence. */
  /* of(...items)—Returns an Observable instance that synchronously delivers the values provided as arguments. */

  private log(message: string) {
    this.messageService.add(`TodoService: ${message}`);
  }

  private handleError<T>(operation = "operation", result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
