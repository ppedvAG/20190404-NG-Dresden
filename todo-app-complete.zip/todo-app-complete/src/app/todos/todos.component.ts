import { TodoService } from './../todo.service';
import { Component, OnInit } from '@angular/core';
import { Todo } from '../todo';

@Component({
  selector: 'app-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {
  todo: Todo = {
    id: 1,
    title: 'shopping',
    done: false
  };
  todos: Todo[];

  constructor(private todoService: TodoService) { }

  ngOnInit() {
    this.getTodos();
  }

  getTodos(): void {
    this.todoService.getTodos()
    .subscribe(todos => this.todos = todos);
  }

  add(title: string): void {
    title = title.trim();
    if (!title) { return; }
    this.todoService.addTodo({title} as Todo)
    .subscribe(todo => {this.todos.push(todo);
    }); //eventuell {}
  }

  delete(todo: Todo): void {
    this.todos = this.todos.filter(todoFilter => todoFilter !== todo);
    this.todoService.deleteTodo(todo).subscribe();
  }





}
