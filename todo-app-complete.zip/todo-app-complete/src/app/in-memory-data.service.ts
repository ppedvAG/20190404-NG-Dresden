import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Todo } from './todo';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService extends InMemoryDbService {
  createDb() {
    const todos = [
      { id: 1, title: 'Feierabend machen'},
      { id: 2, title: 'einkaufen'},
      { id: 3, title: 'Sport machen'},
      { id: 4, title: 'Fahhrad reparieren'},
      { id: 5, title: 'Kaffee holen'}
    ];
    return {todos};
  }
  genId(todos: Todo[]): number {
    return todos.length > 0 ? Math.max(...todos.map(todo => todo.id)) + 1 : 1;
  }
}
