import { BankaccountService } from './../bankaccount.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-form',
  templateUrl: './add-form.component.html',
  styleUrls: ['./add-form.component.css']
})
export class AddFormComponent implements OnInit {
  constructor(private bas: BankaccountService) { }
  ngOnInit() {
  }
  onSubmit(formValue) {
        this.bas.addTransaction(formValue.descr, new Date(Date.now()).toLocaleDateString(), formValue.amount );
  }
}
