import { Injectable } from '@angular/core';
import { Transaction } from './transaction';

@Injectable({
  providedIn: 'root'
})
export class BankaccountService {
  initialBalance: number;
  transactions: Transaction[] = [];

  constructor() { }

  addTransaction(description: string, date: string, amount: number) {
    this.transactions.push(new Transaction(description, date, amount));
  }

  loadDemoData() {
    this.initialBalance = 255;
    this.addTransaction('shoppen', '2019-04-03', -35.55);
    this.addTransaction('gehalt', '2019-04-01', 3002.55);
    this.addTransaction('auto reparatur', '2019-04-02', -145.55);
  }

  getBalance(): number {
    let balance = this.initialBalance;
    for (const tr of this.transactions) {
      balance += tr.amount;
    }
    return balance;
  }


}
