import { BankaccountService } from './bankaccount.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my-finance';
  constructor(public bankaccountService: BankaccountService) {

  }

// tslint:disable-next-line: use-life-cycle-interface
  ngOnInit() {
    this.bankaccountService.loadDemoData();
  }


}
