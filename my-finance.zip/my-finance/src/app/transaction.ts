export class Transaction {
    constructor(
        public description: string,
        public date: string,
        public amount: number
    ) { }

}
