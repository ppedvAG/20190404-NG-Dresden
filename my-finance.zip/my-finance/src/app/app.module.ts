import { BankaccountService } from './bankaccount.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AddFormComponent } from './add-form/add-form.component';
import { AmountComponent } from './amount/amount.component';

@NgModule({
  declarations: [
    AppComponent,
    AddFormComponent,
    AmountComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [
    BankaccountService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
