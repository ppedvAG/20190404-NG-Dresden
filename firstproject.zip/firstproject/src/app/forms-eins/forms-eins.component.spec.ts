import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormsEinsComponent } from './forms-eins.component';

describe('FormsEinsComponent', () => {
  let component: FormsEinsComponent;
  let fixture: ComponentFixture<FormsEinsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormsEinsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormsEinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
