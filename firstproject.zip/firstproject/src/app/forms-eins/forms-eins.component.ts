import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-eins',
  templateUrl: './forms-eins.component.html',
  styleUrls: ['./forms-eins.component.css']
})
export class FormsEinsComponent implements OnInit {
test2wayBinding: string;
  constructor() { }

  ngOnInit() {
  }

}
