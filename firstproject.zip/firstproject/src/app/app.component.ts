import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myproject';
  city: string;
  timerMessage: string;

  handleTick(second: number) {
    this.timerMessage = `Remaining Time: ${second}`;
  }

  handleStart() {
    this.timerMessage = 'Timer started!';
  }


}
