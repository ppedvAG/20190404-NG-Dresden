import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forms-two',
  templateUrl: './forms-two.component.html',
  styleUrls: ['./forms-two.component.css']
})
export class FormsTwoComponent implements OnInit {
  firstname: string;
  lastname: string;

  constructor() { }

  ngOnInit() {
  }
  checkForm(arg) {
    this.firstname = arg.fname;
    this.lastname = arg.lname;
  }

}
