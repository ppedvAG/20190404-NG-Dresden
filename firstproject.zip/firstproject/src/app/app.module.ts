import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TimeComponent } from './time/time.component';
import { DiceComponent } from './dice/dice.component';
import { RomanNumberComponent } from './roman-number/roman-number.component';
import { RatingComponent } from './rating/rating.component';
import { KeycodeDisplayComponent } from './keycode-display/keycode-display.component';
import { TimerComponent } from './timer/timer.component';
import { FormsEinsComponent } from './forms-eins/forms-eins.component';
import { FormsTwoComponent } from './forms-two/forms-two.component';

@NgModule({
  declarations: [
    AppComponent,
    TimeComponent,
    DiceComponent,
    RomanNumberComponent,
    RatingComponent,
    KeycodeDisplayComponent,
    TimerComponent,
    FormsEinsComponent,
    FormsTwoComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
