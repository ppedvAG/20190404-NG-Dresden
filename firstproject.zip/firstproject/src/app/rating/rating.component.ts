import { Component, OnInit, OnChanges, Input } from '@angular/core';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {

  stern: string = '*';
  @Input() amount_of_stars: number = 1;
  rating: string;

  constructor() {
  }

  ngOnInit() {
  }

  ngOnChanges() {
    this.rating = this.stern.repeat(this.amount_of_stars);
  }

}
