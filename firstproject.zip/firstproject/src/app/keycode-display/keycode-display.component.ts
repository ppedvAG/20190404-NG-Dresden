import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-keycode-display',
  templateUrl: './keycode-display.component.html',
  styleUrls: ['./keycode-display.component.css']
})
export class KeycodeDisplayComponent implements OnInit {
  size:number = 16;
  key:string;
  keycode:number;

  constructor() { }

  ngOnInit() {
  }
  changeSize(arg: any) {
    /* for (let iterator in arg) {
      console.log(`${iterator}: ${arg[iterator]}`);
    } */

    this.size = arg.target.value;
  }
  onKeyDown (ev: KeyboardEvent) {
    /* this.key = ev.key; */
    /* console.log(`ev.key: ${ev.key}`); */
    this.keycode = ev.key.charCodeAt(0);
    /* console.log(`ev.key.keycode: ${ev.key.charCodeAt(0)}`); */
  }
}
